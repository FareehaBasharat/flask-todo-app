# Flask To-Do App

A simple To-Do List web application built using Flask.

## Features
- Add new tasks
- View tasks
- Delete tasks
- Clean UI

## Technologies Used
- Python
- Flask
- HTML
- CSS

## Purpose
This project was created to demonstrate Flask basics and CRUD operations for internship applications.
